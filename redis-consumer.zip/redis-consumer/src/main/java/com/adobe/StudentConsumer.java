package com.adobe;

import org.springframework.stereotype.Component;

@Component
public class StudentConsumer {

	public void handleMessage(Student student) {
		System.out.println("Consumer> " + student);
	}
}