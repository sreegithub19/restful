package com.example.demo.dao;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import com.example.demo.entity.Person;
import com.example.demo.entity.PersonVO;

public interface PersonDao extends PagingAndSortingRepository<Person, Long>, QueryByExampleExecutor<Person> {

	 Slice<Person> findByAgeBetween(int start, int end, Pageable pageable);
	 
	 List<PersonVO> findBy();
}
