package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.domain.Sort;

import com.example.demo.dao.PersonDao;
import com.example.demo.entity.Person;
import com.example.demo.entity.PersonVO;

@SpringBootApplication
public class PaginationExampleApplication implements CommandLineRunner {

	@Autowired
	private PersonDao personDao;

	public static void main(String[] args) {
		SpringApplication.run(PaginationExampleApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		List<PersonVO> list = personDao.findBy();
		for(PersonVO p : list) {
			System.out.println(p.getFullName() + "," + p.getAge());
		}
		System.out.println("*********");
		Pageable pageable = PageRequest.of(0, 3);
		Page<Person> personPage = personDao.findAll(pageable);

		System.out.println("Pages : " + personPage.getTotalPages());

		personPage.getContent().forEach(System.out::println);

		System.out.println();

		Slice<Person> personSlice = personDao.findByAgeBetween(30, 40, pageable);
		personSlice.getContent().forEach(System.out::println);

		System.out.println();

		pageable = PageRequest.of(0, 3, Sort.by("age").ascending().and(Sort.by("lastName").descending()));
		personSlice = personDao.findByAgeBetween(30, 50, pageable);
		personSlice.getContent().forEach(System.out::println);
		System.out.println("Next Page available : " + personSlice.hasNext());

		System.out.println("*********************");
		System.out.println("QBE");

		

//		Person p = new Person();
//		p.setLastName("Rao");
//		ExampleMatcher matcher = ExampleMatcher.matching().withMatcher("lastName", 
//				// can be replaced with lambda
//				new ExampleMatcher.MatcherConfigurer<ExampleMatcher.GenericPropertyMatcher>() {
//					@Override
//					public void configureMatcher(ExampleMatcher.GenericPropertyMatcher matcher) {
//						matcher.ignoreCase().startsWith();
//					}
//				}) .withIgnorePaths("age");

		
		ExampleMatcher matcher = 
				ExampleMatcher.matching()
				.withMatcher("lastName", 
				 match -> match.ignoreCase().startsWith()) 
				.withIgnorePaths("age");


		
		Person p = new Person();
		p.setLastName("Rao");
		Example<Person> example = Example.of(p,matcher);
		
		personDao.findAll(example).forEach(System.out::println);

	}

}
