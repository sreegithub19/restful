package com.example.demo.entity;

import org.springframework.beans.factory.annotation.Value;

public interface PersonVO {
	@Value("#{target.firstName + ' ' + target.lastName}")
	String getFullName();
	String getFirstName();
	int getAge();
}
