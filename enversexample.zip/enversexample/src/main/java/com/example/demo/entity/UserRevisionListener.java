package com.example.demo.entity;

import org.hibernate.envers.RevisionListener;

public class UserRevisionListener implements RevisionListener {

    public final static String USERNAME = "Banuprakash"; // get from login

    @Override
    public void newRevision(Object revisionEntity) {
        UserRevEntity exampleRevEntity = (UserRevEntity) revisionEntity;
        exampleRevEntity.setUsername(USERNAME);
    }
}