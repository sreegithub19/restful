package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class RedisCacheApplication implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(RedisCacheApplication.class);

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private RedisService service; 
	
	public static void main(String[] args) {
		SpringApplication.run(RedisCacheApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info(".... Fetching books");
		logger.info("isbn-1234 -->" + bookRepository.getByIsbn("isbn-1234"));
		logger.info("isbn-4567 -->" + bookRepository.getByIsbn("isbn-4567"));
		logger.info("isbn-1234 -->" + bookRepository.getByIsbn("isbn-1234"));
		logger.info("isbn-4567 -->" + bookRepository.getByIsbn("isbn-4567"));
		logger.info("update isbn-1234 -->" + bookRepository.updateBook("isbn-4567", "New title"));
		logger.info("isbn-1234 -->" + bookRepository.getByIsbn("isbn-1234"));
//		 bookRepository.deleteBook("isbn-4567");
		logger.info("isbn-1234 -->" + bookRepository.getByIsbn("isbn-1234"));
	
		service.printDetails();
	}
}
